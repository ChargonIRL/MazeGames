/*
	GPF Week 6 - Maze Start Code
*/

#include <iostream>
#include <vector>
#include <time.h>
#include <stdio.h>
#include <string>
#include <fstream>
#include <map>


#include "Framework.h"
using namespace std;

// Screen dimensions
int gScreenWidth{ 800 };
int gScreenHeight{ 600 };

// Delay to slow things down
int gTimeDelayMS{ 100 };

// Maze size as constants
constexpr int kMazeColumnsX{ 20 };
constexpr int kMazeRowsY{ 20 };

int level = 1;
ifstream load;
ofstream save;
string filename;

map<string, int> Highscore;

/*
	2 Dimensional Arrays
	You can think of these as being an array of arrays

	The maze has kMazeColumnsX columns across (20 by default) represented by an array
	We then have kMazeRowsY (20) of these arrays, one for each row

	Columns and rows can be confusing so you can prefer working with x and y
	where x is the horizontal axis (columns) across and y is the vertical axis (rows) down.

	Each single array entry is called a cell.

	E.g. to output the value of the cell at 16 X (column 16) and 1 Y (row 1) we would write:
	cout << maze[1][16] << endl; // outputs G
*/

char maze[kMazeRowsY][kMazeColumnsX];

void FogOfWar(int y, int x);

void SaveMaze(string filename)
{
	save.open(filename);
	for (size_t i = 0; i < kMazeRowsY; i++)
	{
		for (size_t j = 0; j < kMazeColumnsX; j++)
		{
			save << maze[i][j] << " ";
		}
		save << endl;
	}
}


void LoadMaze(string filename)
{
	load.open(filename);
	if (!load)
	{
		cerr << "File did not load" << endl;
	}
	for (size_t i = 0; i < kMazeRowsY; i++)
	{
		for (size_t j = 0; j < kMazeColumnsX; j++)
		{
			load >> maze[i][j];
		}
	}
	load.close();
	
}

void DrawMaze()
{
	for (int y = 0; y < kMazeRowsY; y++)
	{
		for (int x = 0; x < kMazeColumnsX; x++)
		{
			int cellWidth = gScreenWidth / kMazeColumnsX;
			int cellHeight = gScreenHeight / kMazeRowsY;
			int cellPosX = x * cellWidth;
			int cellPosY = y * cellHeight;


			if (maze[y][x] == 'P')
			{
				ChangeColour(0, 0, 255);
				//DrawRectangle(cellPosX, cellPosY, cellWidth, cellHeight);
				//FogOfWar(y, x);

			}
			else if (maze[y][x] == 'W')
			{
				ChangeColour(0, 0, 0);
			}
			else if (maze[y][x] == '.')
			{
				ChangeColour(255, 255, 255);
			}
			else if (maze[y][x] == 'G')
			{
				ChangeColour(0, 255, 0);
			}
			else if (maze[y][x] == 'F')
			{
				ChangeColour(255, 165, 0);
			}
			else if (maze[y][x] == 'A')
			{
				ChangeColour(112, 41, 99);
			}
			else if (maze[y ][x] == 'K')
			{
				ChangeColour(255, 255, 0);
			}
			else if (maze[y][x] == 'D')
			{
				ChangeColour(123, 63, 0);
			}
			else if (maze[y][x] == 'S')
			{
				ChangeColour(175, 176, 165);
			}
			else if (maze[y][x] == 'N')
			{
				ChangeColour(237, 243, 161);
			}
			else if (maze[y][x] == 'T')
			{
				ChangeColour(255, 0, 0);
			}
			else if (maze[y][x] == 'H')
			{
				ChangeColour(255, 0, 220);
				cellHeight = (gScreenHeight / kMazeRowsY) / 2;
				cellPosY = cellPosY + 7;
			}
			DrawRectangle(cellPosX, cellPosY, cellWidth, cellHeight);
		}
	}
}

bool wallBlocking(bool WN, bool WS, bool WE, bool WW, int i)
{
	if (WN == true && i == 4)
	{
		return true;
	}
	else if (WE == true && i == 5)
	{
		return true;
	}
	else if (WS == true && i == 6)
	{
		return true;
	}
	else if (WW == true && i == 7)
	{
		return true;
	}
	else
	{
		return false;
	}
}


void isWall(bool& WN, bool& WS, bool& WE, bool& WW, int i)
{
	if (i == 0)
	{
		WN = true;
	}
	else if (i == 1)
	{
		WE = true;
	}
	else if (i == 2)
	{
		WS = true;
	}
	else if (i == 3)
	{
		WW = true;
	}
}


void Offset(int& xOffset, int& yOffset, int i)
{
	if (i == 0)
	{
		yOffset = -1;
		xOffset = 0;
	}
	else if (i == 1)
	{
		yOffset = 0;
		xOffset = 1;
	}
	else if (i == 2)
	{
		yOffset = 1;
		xOffset = 0;
	}
	else if (i == 3)
	{
		yOffset = 0;
		xOffset = -1;
	}
	else if (i == 4)
	{
		yOffset = -2;
		xOffset = 0;
	}
	else if (i == 5)
	{
		yOffset = 0;
		xOffset = 2;
	}
	else if (i == 6)
	{
		yOffset = 2;
		xOffset = 0;
	}
	else if (i == 7)
	{
		yOffset = 0;
		xOffset = -2;
	}
}


void FogOfWar(int y, int x)
{
	int xOffset;
	int yOffset;

	bool WallN = false;
	bool WallE = false;
	bool WallS = false;
	bool WallW = false;

	for (int i = 0; i < 8; i++)
	{
		int cellWidth = gScreenWidth / kMazeColumnsX;
		int cellHeight = gScreenHeight / kMazeRowsY;
		int cellPosX = x * cellWidth;
		int cellPosY = y * cellHeight;

		Offset(xOffset,yOffset,i);
		

		if (maze[y + yOffset][x + xOffset] == 'W')
		{
			ChangeColour(0, 0, 0);
			
			isWall(WallN,WallS,WallE,WallW,i);

		}
		else if (maze[y + yOffset][x + xOffset] == '.')
		{
			if (wallBlocking(WallN, WallS, WallE, WallW, i))
			{
				ChangeColour(0, 0, 0);
			}
			else
			{
				ChangeColour(255, 255, 255);
			}
			
		}
		else if (maze[y + yOffset][x + xOffset] == 'G')
		{
			if (wallBlocking(WallN, WallS, WallE, WallW, i))
			{
				ChangeColour(0, 0, 0);
			}
			else
			{
				ChangeColour(0, 255, 0);
			}
		}
		else if (maze[y + yOffset][x + xOffset] == 'F')
		{
			if (wallBlocking(WallN, WallS, WallE, WallW, i))
			{
				ChangeColour(0, 0, 0);
			}
			else
			{
				ChangeColour(255, 165, 0);
			}
		}
		else if (maze[y + yOffset][x + xOffset] == 'A')
		{
			if (wallBlocking(WallN, WallS, WallE, WallW, i))
			{
				ChangeColour(0, 0, 0);
			}
			else
			{
				ChangeColour(112, 41, 99);
			}
		}
		else if (maze[y + yOffset][x + xOffset] == 'K')
		{
			if (wallBlocking(WallN, WallS, WallE, WallW, i))
			{
				ChangeColour(0, 0, 0);
			}
			else
			{
				ChangeColour(255, 255, 0);
			}
		}
		else if (maze[y + yOffset][x + xOffset] == 'D')
		{
			isWall(WallN, WallS, WallE, WallW, i);

			if (wallBlocking(WallN, WallS, WallE, WallW, i))
			{
				ChangeColour(0, 0, 0);
			}
			else
			{
				ChangeColour(123, 63, 0);
			}
		}
		else if (maze[y + yOffset][x + xOffset] == 'S')
		{
			isWall(WallN, WallS, WallE, WallW, i);

			if (wallBlocking(WallN, WallS, WallE, WallW, i))
			{
				ChangeColour(0, 0, 0);
			}
			else
			{
				ChangeColour(175, 176, 165);
			}
			
		}
		else if (maze[y + yOffset][x + xOffset] == 'N')
		{
			if (wallBlocking(WallN, WallS, WallE, WallW, i))
			{
				ChangeColour(0, 0, 0);
			}
			else
			{
				ChangeColour(237, 243, 161);
			}
			
		}
		else if (maze[y + yOffset][x + xOffset] == 'T')
		{
			if (wallBlocking(WallN, WallS, WallE, WallW, i))
			{
				ChangeColour(0, 0, 0);
			}
			else
			{
				ChangeColour(255, 0, 0);
			}
			
		}
		else if (maze[y + yOffset][x + xOffset] == 'H')
		{
			if (wallBlocking(WallN, WallS, WallE, WallW, i))
			{
				ChangeColour(0, 0, 0);
			}
			else
			{
				ChangeColour(255, 0, 220);
				cellHeight = (gScreenHeight / kMazeRowsY) / 2;
				cellPosY = cellPosY + 7;
			}
			
		}
		DrawRectangle(cellPosX + (xOffset * cellWidth), cellPosY + (yOffset * cellHeight), cellWidth, cellHeight);
	}
}

void NewGoal()
{
	bool newGoalFound = false;
	while (newGoalFound == false)
	{
		int newGoalPosX = rand() % kMazeColumnsX;
		int newGoalPosY = rand() % kMazeRowsY;
		if (maze[newGoalPosY][newGoalPosX] == '.')
		{
			maze[newGoalPosY][newGoalPosX] = 'G';
			newGoalFound = true;
		}
	}
}

void PlayerStart()
{
	bool playerBegin = false;

	while (playerBegin == false)
	{
		int playerStartX = rand() % kMazeColumnsX;
		int playerStartY = rand() % kMazeRowsY;
		if (maze[playerStartY][playerStartX] == '.')
		{
			maze[playerStartY][playerStartX] = 'P';
			playerBegin = true;
		}
	}
}

bool CanMoveThere(int x, int y , bool& keysCollected, int combination)
{
	if (maze[y][x] != 'W' && maze[y][x] != 'T')
	{
		if (maze[y][x] == 'D')
		{
			if (keysCollected == true)
			{
				return true;
			}
			else
			{
				return false;
			}
			
		}
		else if (maze[y][x] == 'S')
		{
			int guess;
			cout << "Please enter the combination" << endl;

			cin >> guess;

			if (guess == combination)
			{
				return true;
			}
			else
			{
				return false;
			}

		}
		else if (maze[y][x] == 'N')
		{
			cout << "You find a note that reads: The combination is " << combination << endl;
			return true;
		}
		else
		{
			return true;
		}
		
	}
	else
	{
		return false;
	}
}

bool CanAIMoveThere(int x, int y)
{

	if (maze[y][x] == '.' || maze[y][x] == 'P')
	{
		return true;
	}
	else
	{
		return false;
	}
}

void AIMovement(int AIPosX, int AIPosY)
{
	int direction = rand() % 4;
	int chance = rand() % 100;
	if (chance <= 50)
	{
		if (direction == 0)
		{
			if (CanAIMoveThere(AIPosX, AIPosY - 1))
			{
				maze[AIPosY][AIPosX] = '.';
				AIPosY--;
				maze[AIPosY][AIPosX] = 'A';
			}
		}
		else if (direction == 1)
		{
			if (CanAIMoveThere(AIPosX, AIPosY + 1))
			{
				maze[AIPosY][AIPosX] = '.';
				AIPosY++;
				maze[AIPosY][AIPosX] = 'A';
			}
		}
		else if (direction == 2)
		{
			if (CanAIMoveThere(AIPosX - 1, AIPosY))
			{
				maze[AIPosY][AIPosX] = '.';
				AIPosX--;
				maze[AIPosY][AIPosX] = 'A';
			}
		}
		else if (direction == 3)
		{
			if (CanAIMoveThere(AIPosX + 1, AIPosY))
			{
				maze[AIPosY][AIPosX] = '.';
				AIPosX++;
				maze[AIPosY][AIPosX] = 'A';
			}
		}
	}
}

void Arrow(int trapPosX, int trapPosY, bool arrow, int& count, int& arrowPosX, int& arrowPosY)
{
	for (size_t x = 0; x < trapPosX; x++)
	{
		if (maze[trapPosY][x] == 'H')
		{
			arrow = true;
			break;
		}
		else
		{
			arrow = false;
		}
	}

	if (arrow != true)
	{
		if (trapPosX == 0)
		{
			cout << "Shouldn't happen" << endl;
		}
		else
		{
			maze[trapPosY][trapPosX - 1] = 'H';
			arrowPosX = trapPosX - 1;
			arrowPosY = trapPosY;
		}
		
	}
	else
	{
		if (count == 3)
		{
			count = 0;
			maze[arrowPosY][arrowPosX] = '.';
			arrowPosX--;
			if (maze[arrowPosY][arrowPosX] != 'W')
			{
				maze[arrowPosY][arrowPosX] = 'H';
			}
		}
		else
		{
			count++;
		}
	}
}

void WriteHighscore(string name, int score)
{
	save.open("Highscore.txt", ios::app);
	if (!save)
	{
		cerr << "File did not open" << endl;
	}
	save << name << endl;
	save << score << endl;
	save.close();

}
void PrintHighscore(map<string, int> Highscore)
{
	string output1;
	string output2;
	load.open("Highscore.txt");
	if (!load)
	{
		cerr << "File did not open" << endl;
	}
	while (!load.eof())
	{
		load >> output1;
		load >> output2;
		cout << output1 << "   " << output2 << endl;
	}
	load.close();
}


int main()
{
	srand(time(NULL));
	int playerPosX;
	int playerPosY;

	int goalPosX;
	int goalPosY;

	int AIPosX = 0;
	int AIPosY = 0;

	int trapPosX;
	int trapPosY;

	int arrowPosX = 0;
	int arrowPosY = 0;

	bool arrow = false;
	int count = 0;

	bool keyCollected = false;

	int firstNum = (rand() % 9 + 1) * 1000;
	int secondNum = (rand() % 9 + 1) * 100;
	int thirdNum = (rand() % 9 + 1) * 10;
	int fourthNum = rand() % 9 + 1;

	int combination = firstNum + secondNum + thirdNum + fourthNum;

	string filename = "Maze"+to_string(level)+ ".txt";

	LoadMaze(filename);
	StartClock();
	//PlayerStart();
	//NewGoal();

	int score = 500;

	while (UpdateFramework())
	{
		ChangeColour(255, 255, 255);
		DrawRectangle(0, 0, gScreenWidth, gScreenHeight);
		DrawMaze();

		for (int y = 0; y < kMazeRowsY; y++)
		{
			for (int x = 0; x < kMazeColumnsX; x++)
			{
				if (maze[y][x] == 'P')
				{
					playerPosX = x;
					playerPosY = y;
				}
				else if (maze[y][x] == 'G')
				{
					goalPosX = x;
					goalPosY = y;
				}
				else if (maze[y][x] == 'A')
				{
					AIPosX = x;
					AIPosY = y;
				}
				else if (maze[y][x] == 'T')
				{
					trapPosX = x;
					trapPosY = y;
				}

			}
		}

		AIMovement(AIPosX, AIPosY);

		//Arrow(trapPosX, trapPosY, arrow, count, arrowPosX, arrowPosY);


		if (playerPosY == AIPosY && playerPosX == AIPosX)
		{
			cout << "You lose" << endl;
			return 0;
		}

		switch (GetLastKeyPressed())
		{
		case EKeyPressed::eLeft:
			if (maze[playerPosY][playerPosX - 1] == 'F')
			{
				cout << "You lose" << endl;
				return 0;
			}
			if (maze[playerPosY][playerPosX - 1] == 'K')
			{
				keyCollected++;

			}
			if (CanMoveThere(playerPosX - 1, playerPosY, keyCollected, combination))
			{
				maze[playerPosY][playerPosX] = '.';
				playerPosX--;
				maze[playerPosY][playerPosX] = 'P';
			}
			break;
		case EKeyPressed::eRight:
			if (maze[playerPosY][playerPosX + 1] == 'F')
			{
				cout << "You lose" << endl;
				return 0;

			}
			if (maze[playerPosY][playerPosX + 1] == 'K')
			{
				keyCollected++;

			}
			if (CanMoveThere(playerPosX + 1, playerPosY, keyCollected,  combination))
			{
				maze[playerPosY][playerPosX] = '.';
				playerPosX++;
				maze[playerPosY][playerPosX] = 'P';
			}
			break;
		case EKeyPressed::eUp:
			if (maze[playerPosY - 1][playerPosX] == 'F')
			{
				cout << "You lose" << endl;

				return 0;
			}
			if (maze[playerPosY - 1][playerPosX] == 'K')
			{
				keyCollected++;

			}
			if (CanMoveThere(playerPosX, playerPosY - 1, keyCollected, combination))
			{
				maze[playerPosY][playerPosX] = '.';
				playerPosY--;
				maze[playerPosY][playerPosX] = 'P';
			}
			break;
		case EKeyPressed::eDown:
			if (maze[playerPosY + 1][playerPosX] == 'F')
			{
				cout << "You lose" << endl;
				return 0;
			}
			if (maze[playerPosY + 1][playerPosX] == 'K')
			{
				keyCollected++;

			}
			if (CanMoveThere(playerPosX, playerPosY + 1, keyCollected, combination))
			{
				maze[playerPosY][playerPosX] = '.';
				playerPosY++;
				maze[playerPosY][playerPosX] = 'P';
			}
			break;
		case EKeyPressed::eSave:
			cout << "Enter the name of the file" << endl;
			cin >> filename;
			SaveMaze(filename);
			break;
		case EKeyPressed::eLoad:
			cout << "Enter the name of the file" << endl;
			cin >> filename;
			LoadMaze(filename);
			break;
			
		default:
			break;
		}

		if (playerPosY == AIPosY && playerPosX == AIPosX)
		{
			cout << "You lose" << endl;
			return 0;
		}
		if (playerPosY == arrowPosY && playerPosX == arrowPosX)
		{
			cout << "You lose" << endl;
			return 0;
		}


		if (playerPosX == goalPosX && playerPosY == goalPosY)
		{
			
			cout << "You Win" << endl;
			level++;
			filename = "Maze" + to_string(level) + ".txt";
			score -= GetElapsedTime();
			if (level < 4)
			{
				LoadMaze(filename);
				keyCollected = false;
				firstNum = (rand() % 9 + 1) * 1000;
				secondNum = (rand() % 9 + 1) * 100;
				thirdNum = (rand() % 9 + 1) * 10;
				fourthNum = rand() % 9 + 1;

				combination = firstNum + secondNum + thirdNum + fourthNum;

				StartClock();
			}
			else
			{
				string name;
				cout << "You scored " << score << " points" << endl;
				cout << "What is your name" << endl;
				cin >> name;
				WriteHighscore(name, score);
				PrintHighscore(Highscore);
				return 0;
			}
			
		}
	}

	return 0;
}
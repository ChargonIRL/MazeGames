/*
	GPF Week 6 - Maze Start Code
*/

#include <iostream>
#include <vector>
#include <time.h>
#include <stdio.h>

#include "Framework.h"
using namespace std;

// Screen dimensions
int gScreenWidth{ 800 };
int gScreenHeight{ 600 };

// Delay to slow things down
int gTimeDelayMS{ 100 };

// Maze size as constants
constexpr int kMazeColumnsX{ 20 };
constexpr int kMazeRowsY{ 20 };

int timeAllowed = 30;

/*
	2 Dimensional Arrays
	You can think of these as being an array of arrays

	The maze has kMazeColumnsX columns across (20 by default) represented by an array
	We then have kMazeRowsY (20) of these arrays, one for each row

	Columns and rows can be confusing so you can prefer working with x and y
	where x is the horizontal axis (columns) across and y is the vertical axis (rows) down.

	Each single array entry is called a cell.

	E.g. to output the value of the cell at 16 X (column 16) and 1 Y (row 1) we would write:
	cout << map[1][16] << endl; // outputs G
*/

char map[kMazeRowsY][kMazeColumnsX] = {
	// 20 columns across (x axis) by 20 rows down (y axis)
	// X0   X1   X2   X3   X4   X5   X6   X7   X8   X9   X10  X11  X12  X13  X14  X15  X16  X17  X18  X19 
	{ 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W' },	//Y0
	{ 'W', '.', '.', '.', '.', 'W', '.', '.', '.', 'W', 'W', '.', '.', '.', '.', 'W', 'G', '.', '.', 'W' },	//Y1
	{ 'W', '.', 'W', 'W', 'W', 'W', 'W', 'W', '.', 'W', '.', '.', 'W', 'W', 'W', 'W', 'W', 'W', '.', 'W' },	//Y2
	{ 'W', '.', 'W', '.', '.', '.', 'W', '.', '.', 'W', '.', 'W', 'W', '.', 'W', '.', '.', '.', '.', 'W' },	//Y3
	{ 'W', '.', 'W', '.', 'W', '.', 'W', '.', 'W', 'W', '.', 'W', 'W', '.', 'W', 'W', 'W', '.', 'W', 'W' },	//Y4
	{ 'W', '.', 'W', '.', 'W', '.', '.', '.', '.', '.', '.', '.', 'W', '.', 'W', '.', '.', '.', '.', 'W' },	//Y5
	{ 'W', '.', 'W', '.', 'W', 'W', 'W', 'F', '.', 'W', 'W', '.', 'W', '.', 'W', '.', 'W', 'F', '.', 'W' },	//Y6
	{ 'W', '.', 'W', '.', 'W', '.', 'W', 'W', 'W', 'W', 'W', '.', 'W', '.', 'W', '.', 'W', 'W', 'W', 'W' },	//Y7
	{ 'W', '.', '.', '.', '.', '.', '.', '.', '.', '.', 'W', '.', '.', '.', 'W', '.', '.', '.', '.', 'W' },	//Y8
	{ 'W', '.', 'W', '.', 'W', '.', 'W', 'W', '.', 'W', 'W', 'W', '.', 'W', 'W', 'W', 'W', '.', 'W', 'W' },	//Y9
	{ 'W', '.', 'W', 'W', 'W', 'W', 'W', 'W', '.', 'W', 'W', 'W', '.', 'W', '.', 'W', 'W', '.', 'W', 'W' },	//Y10
	{ 'W', '.', '.', '.', '.', 'W', '.', '.', '.', 'W', 'W', '.', '.', '.', '.', 'W', '.', '.', '.', 'W' },	//Y11
	{ 'W', '.', 'W', 'W', 'W', 'W', 'W', 'W', 'F', '.', '.', '.', 'W', 'F', 'W', 'W', 'W', 'W', '.', 'W' },	//Y12
	{ 'W', '.', 'W', '.', '.', '.', 'W', '.', '.', 'W', 'W', '.', 'W', '.', 'W', '.', '.', '.', '.', 'W' },	//Y13
	{ 'W', '.', 'W', '.', 'W', '.', 'W', '.', 'W', 'W', 'W', '.', 'W', '.', 'W', '.', 'W', 'W', 'W', 'W' },	//Y14
	{ 'W', '.', 'W', '.', 'W', '.', '.', '.', '.', '.', 'W', '.', 'W', '.', 'W', '.', '.', '.', 'W', 'W' },	//Y15
	{ 'W', '.', 'W', '.', 'W', 'W', 'W', 'F', '.', 'W', 'W', '.', 'W', '.', '.', '.', 'W', '.', '.', 'W' },	//Y16
	{ 'W', '.', 'W', '.', 'W', '.', 'W', 'W', 'W', 'W', '.', '.', 'W', 'W', 'W', 'F', 'W', 'W', '.', 'W' },	//Y17
	{ 'W', '.', '.', '.', '.', '.', '.', '.', '.', 'W', '.', '.', '.', '.', '.', '.', '.', '.', '.', 'W' },	//Y18
	{ 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W' },	//Y19
};

void DrawMaze()
{
	int cellWidth = gScreenWidth / kMazeColumnsX;
	int cellHeight = gScreenHeight / kMazeRowsY;

	for (size_t y = 0; y < 20; y++)
	{
		for (size_t x = 0; x < 20; x++)
		{
			int cellPosX = x * cellWidth;
			int cellPosY = y * cellHeight;

			if (map[y][x] == 'W')
			{
				ChangeColour(0, 0, 0);
			}
			else if (map[y][x] == '.')
			{
				ChangeColour(255, 255, 255);
				
			}
			else if (map[y][x] == 'P')
			{
				ChangeColour(0, 0, 255);
			}
			else if (map[y][x] == 'G')
			{
				ChangeColour(255, 0, 0);
			}
			else if (map[y][x] == 'F')
			{
				ChangeColour(255, 165, 0);
			}
			else if (map[y][x] == 'A')
			{
				ChangeColour(112, 41, 99);
			}
			

			DrawRectangle(cellPosX, cellPosY, cellWidth, cellHeight);
		}
	}
}

void NewGoal()
{
	bool newGoalFound = false;
	while (newGoalFound == false)
	{
		int newGoalPosX = rand() % kMazeColumnsX;
		int newGoalPosY = rand() % kMazeRowsY;
		if (map[newGoalPosY][newGoalPosX] == '.')
		{
			map[newGoalPosY][newGoalPosX] = 'G';
			newGoalFound = true;
		}
	}
}

void PlayerStart()
{
	bool playerBegin = false;

	while (playerBegin == false)
	{
		int playerStartX = rand() % kMazeColumnsX;
		int playerStartY = rand() % kMazeRowsY;
		if (map[playerStartY][playerStartX] == '.')
		{
			map[playerStartY][playerStartX] = 'P';
			playerBegin = true;
		}
	}
}

bool CanMoveThere(int x, int y)
{

	if (map[y][x] != 'W')
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool CanAIMoveThere(int x, int y)
{

	if (map[y][x] != 'W' && map[y][x] !='F' && map[y][x] != 'G')
	{
		return true;
	}
	else
	{
		return false;
	}
}

void AIMovement(int AIPosX, int AIPosY)
{
	int direction = rand() % 4;
	int chance = rand() % 100;
	if (chance <= 50)
	{
		if (direction == 0)
		{
			if (CanAIMoveThere(AIPosX, AIPosY - 1))
			{
				map[AIPosY][AIPosX] = '.';
				AIPosY--;
				map[AIPosY][AIPosX] = 'A';
			}
		}
		else if (direction == 1)
		{
			if (CanAIMoveThere(AIPosX, AIPosY + 1))
			{
				map[AIPosY][AIPosX] = '.';
				AIPosY++;
				map[AIPosY][AIPosX] = 'A';
			}
		}
		else if (direction == 2)
		{
			if (CanAIMoveThere(AIPosX - 1, AIPosY))
			{
				map[AIPosY][AIPosX] = '.';
				AIPosX--;
				map[AIPosY][AIPosX] = 'A';
			}
		}
		else if (direction == 3)
		{
			if (CanAIMoveThere(AIPosX + 1, AIPosY))
			{
				map[AIPosY][AIPosX] = '.';
				AIPosX++;
				map[AIPosY][AIPosX] = 'A';
			}
		}
	}
}

int main()
{
	srand(time(NULL));
	int playerPosX;
	int playerPosY;

	int goalPosX;
	int goalPosY;

	int AIPosX = 0;
	int AIPosY = 0;
	
	StartClock();
	PlayerStart();

	cout << "You have " << timeAllowed << " seconds to get to the goal" << endl;

	while (UpdateFramework())
	{
		DrawMaze();


		for (size_t y = 0; y < kMazeRowsY; y++)
		{
			for (size_t x = 0; x < kMazeColumnsX; x++)
			{
				if (map[y][x] == 'P')
				{
					playerPosX = x;
					playerPosY = y;
					break;

				}
			}
		}
		for (size_t y = 0; y < kMazeRowsY; y++)
		{
			for (size_t x = 0; x < kMazeColumnsX; x++)
			{
				if (map[y][x] == 'G')
				{
					goalPosX = x;
					goalPosY = y;
					break;

				}
			}
		}
		for (size_t y = 0; y < kMazeRowsY; y++)
		{
			for (size_t x = 0; x < kMazeColumnsX; x++)
			{
				if (map[y][x] == 'A')
				{
					AIPosX = x;
					AIPosY = y;
					break;

				}
			}
		}

		//AIMovement(AIPosX, AIPosY);

		if (playerPosY == AIPosY && playerPosX == AIPosX)
		{
			cout << "You lose" << endl;
			return 0;
		}

		switch (GetLastKeyPressed())
		{
		case EKeyPressed::eLeft:
			if (map[playerPosY][playerPosX - 1] == 'F')
			{
				cout << "You lose" << endl;
				return 0;
				
			}
			if (CanMoveThere(playerPosX - 1, playerPosY))
			{
				map[playerPosY][playerPosX] = '.';
				playerPosX--;
				map[playerPosY][playerPosX] = 'P';
			}
			break;
		case EKeyPressed::eRight:
			if (map[playerPosY][playerPosX + 1] == 'F')
			{
				cout << "You lose" << endl;
				return 0;

			}
			if (CanMoveThere(playerPosX + 1, playerPosY))
			{
				map[playerPosY][playerPosX] = '.';
				playerPosX++;
				map[playerPosY][playerPosX] = 'P';
			}
			break;
		case EKeyPressed::eUp:
			if (map[playerPosY - 1][playerPosX] == 'F')
			{
				cout << "You lose" << endl;
				
				return 0;
			}
			if (CanMoveThere(playerPosX, playerPosY - 1))
			{
				map[playerPosY][playerPosX] = '.';
				playerPosY--;
				map[playerPosY][playerPosX] = 'P';
			}
			break;
		case EKeyPressed::eDown:
			if (map[playerPosY + 1][playerPosX] == 'F')
			{
				cout << "You lose" << endl;
				return 0;
			}
			if (CanMoveThere(playerPosX, playerPosY + 1))
			{
				map[playerPosY][playerPosX] = '.';
				playerPosY++;
				map[playerPosY][playerPosX] = 'P';
			}
			break;

		default:
			break;
		}

		if (playerPosY == AIPosY && playerPosX == AIPosX)
		{
			cout << "You lose" << endl;
			return 0;
		}

		if (GetElapsedTime() > timeAllowed)
		{
			cout << "You took too long" << endl;
			return 0;
		}


		if (playerPosX == goalPosX && playerPosY == goalPosY)
		{
			cout << GetElapsedTime() << endl;
			
			cout << "You Win" << endl;
			goalPosX = 0;
			NewGoal();
			timeAllowed--;
			cout << "You have " << timeAllowed << " seconds to get to the goal" << endl;
			StartClock();
		}
	}

	return 0;
}